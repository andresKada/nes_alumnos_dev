CREATE FUNCTION average(valores numeric[], OUT prom numeric)
  RETURNS numeric
LANGUAGE plpgsql
AS $$
DECLARE
	element_count INT4;
	sum numeric := 0.0;
BEGIN

	element_count := array_upper(valores, 1) - array_lower(valores, 1) +1;
	FOR i IN array_lower(valores, 1) .. array_upper(valores, 1)
	LOOP
		sum := sum + valores[i];
	END LOOP;
	prom := trunc(sum/element_count,1);
END;
$$;

